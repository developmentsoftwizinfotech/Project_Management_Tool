import React from 'react'
import { useNavigate } from 'react-router-dom'
import UpdateTask from './UpdateTask';

const Tasks = () => {
    const navigate = useNavigate();
  return (
    <>
    <div className='flex flex-col justify-start items-start ' >

<p className="text-teal-600 text-2xl pl-6 py-5 ">Project Name</p>

            <div className="text-gray-700 w-full mb-5">
                <div className='w-full px-6' >
                    <div type="button" className="flex items-center  justify-between w-full p-5 font-medium text-left text-gray-900 bg-gray-100 border border-b-0 border-gray-200 rounded-t-xl dark:focus:ring-gray-800 dark:border-gray-700 dark:text-white dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-800" >
                        <span>module name</span>
                        {/* <button type="button" onClick={()=>navigate('/addproject')} className="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-gray-900  bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700   dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">
                            Edit
                        </button> */}
                    </div>

                    <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
                    
                        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400 ">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                <tr>
                                    <th scope="col" className="px-6 py-3">
                                        Task
                                    </th>
                                    <th scope="col" className="px-6 py-3">
                                        Duration(hour)
                                    </th>
                                    <th scope="col" className="px-6 py-3">
                                        Status
                                    </th>
                                    <th scope="col" className="px-6 py-3">
                                        Total Time(hour)
                                    </th>
                                    <th scope="col" className="px-6 py-3">
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                    <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                        name
                                    </th>
                                    <td className="px-6 py-4">
                                        7hr
                                    </td>
                                    <td className="px-6 py-4">
                                        hr
                                    </td>
                                    <td className="px-6 py-4">
                                    pending
                                    </td>
                                    <td className="px-6 py-4">
                                    <UpdateTask />

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>

        </div>
        
    </>
  )
}

export default Tasks