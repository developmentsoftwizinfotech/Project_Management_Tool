import React from 'react'


const HomePage = () => {
  return (
    <div>
        <p>hello</p>
     
    </div>
  )
}

export default HomePage