export const paths = {

//  login
    login : 'login',
    signup : 'signup',

// admin
    // project

        addProject : 'project',
        projectList : 'projectList',
        projectDetail : 'project/',
        assignTask : 'assignTask/',

    //  Teams
        users : 'users',
        userDetail : 'users/',
        searchUser : 'searchuser?userName=',
        deleteUser : 'deleteuser/',

}