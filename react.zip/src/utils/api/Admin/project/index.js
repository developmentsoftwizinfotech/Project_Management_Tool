import api from "../.."
import { paths } from "../../endPoints"


export const addProject = async(data) =>{
    const url = await api.post(paths.addProject,data)
    return url?.data
}

export const projectList = async() =>{
    const url = await api.get(paths.projectList)
    return url?.data
}

export const projectDetails = async(id) =>{
    const url = await api.get(paths.projectDetail+id)
    return url?.data
}

export const assignTask = async({id,data})=>{
    const url = await api.put(paths.assignTask+id,data)
    return url
}